/**
 * 
 */
package service;

import vo.logInVO;
import bo.logInBO;

/**
 * @author 
 *
 */
public class logInService {
	private logInBO logInBO;
	/**
	 * @return the logInBO
	 */
	public logInBO getLogInBO() {
		return logInBO;
	}
	/**
	 * @param logInBO the logInBO to set
	 */
	public void setLogInBO(logInBO logInBO) {
		this.logInBO = logInBO;
	}
	public logInVO saveUserDetails(logInVO logInDetails){
		return logInBO.saveUserDetails(logInDetails);
	}
}
