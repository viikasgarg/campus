package action;

import java.io.FileNotFoundException;
import java.io.IOException;

public class child extends parent {
	private static int i = 1;

	@Override
	public void test() throws FileNotFoundException {
		// TODO Auto-generated method stub
		System.out.println("child..!!");
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i = 2;
		System.out.println(i);
	}

}
