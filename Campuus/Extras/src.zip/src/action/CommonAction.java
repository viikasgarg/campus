package action;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.struts2.interceptor.ServletResponseAware;

import com.opensymphony.xwork2.ActionSupport;

public class CommonAction extends ActionSupport implements ServletRequestAware,
		ServletResponseAware {

	/**
	 * 
	 */
	private static final long serialVersionUID = 14234L;

	// servlet request object
	protected HttpServletRequest request;

	// servlet response object
	protected HttpServletResponse response;

	// servlet session object
	protected HttpSession session = null;

	// servlet context object
	protected ServletContext servletContext = null;

	/**
	 * @return the request
	 */
	public HttpServletRequest getRequest() {
		return this.request;
	}

	/**
	 * @param request
	 *            Sets the HTTP request object
	 */
	public void setServletRequest(final HttpServletRequest request) {
		this.request = request;
	}

	/**
	 * @return the response
	 */
	public HttpServletResponse getResponse() {
		return this.response;
	}

	/**
	 * @param response
	 *            Sets the HTTP response object
	 */
	public void setServletResponse(final HttpServletResponse response) {
		this.response = response;
	}

	/**
	 * @return the servletContext
	 */
	public ServletContext getServletContext() {
		return this.servletContext;
	}

	/**
	 * @param servletContext
	 *            Sets the context object
	 */
	public void setServletContext(ServletContext servletContext) {
		this.servletContext = servletContext;
	}

	public Object getObjectFromSession(String key) {
		session = request.getSession(true);
		if (null != session.getAttribute(key)) {
			return (Object) session.getAttribute(key);
		}
		return null;
	}
}
