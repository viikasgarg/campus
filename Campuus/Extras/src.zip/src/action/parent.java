package action;

import java.io.IOException;

public class parent {
	protected void test() throws Exception{
	System.out.println("parent..!!!");
}
}
