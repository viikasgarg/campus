package action;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.InterceptorRef;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;
import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.struts2.interceptor.ServletResponseAware;
import org.apache.struts2.interceptor.validation.SkipValidation;

import com.opensymphony.xwork2.ActionSupport;

import utl_package.Common;
import vo.SignUpVO;
import dao.UserDAO;

@ParentPackage(value = "certi-default")
@InterceptorRef("jsonValidationWorkflowStack")
public class SettingUserAction extends ActionSupport implements
		ServletRequestAware, ServletResponseAware {

	private SignUpVO logInDetails = new SignUpVO();

	private UserDAO userDAO = new UserDAO();

	private String oldUserId;

	private char pwdChngFlag;

	private char savePwdChngFlag = 'N';

	// servlet request object
	protected HttpServletRequest request;

	// servlet response object
	protected HttpServletResponse response;

	// servlet session object
	protected HttpSession session = null;

	// servlet context object
	protected ServletContext servletContext = null;

	/**
	 * @return the oldUserId
	 */
	public String getOldUserId() {
		return oldUserId;
	}

	/**
	 * @param oldUserId
	 *            the oldUserId to set
	 */
	public void setOldUserId(String oldUserId) {
		this.oldUserId = oldUserId;
	}

	@Action(value = "/popUpEditSettings", results = { @Result(location = "editSetting.jsp", name = "success") })
	@SkipValidation
	public String popUpEditSettings() {
		System.out.println("Settings action popup callled");
		// get the object from session

		logInDetails = (SignUpVO) getObjectFromSession("logInSessionKey");
		System.out.println(logInDetails.getEMailId() + "asdfsdf"
				+ logInDetails.getPWD_HASH());
		setOldUserId(logInDetails.getEMailId());
		return "success";
	}

	@Action(value = "/saveModifiedDtls", results = {
			@Result(location = "editSetting.jsp", name = "input"),
			@Result(location = "sucessResult.jsp", name = "success") })
	public String saveModifiedDtls() {
		System.out.println("Setting save action popup callled");
		// save the details corresponding to User Id
		System.out.println(savePwdChngFlag);
		userDAO.saveModDetails(logInDetails, savePwdChngFlag);
		String eMailId = logInDetails.getEMailId();
		String chngdPwd = logInDetails.getPWD_HASH();
		logInDetails = (SignUpVO) getObjectFromSession("logInSessionKey");
		logInDetails.setEMailId(eMailId);
		logInDetails.setUserName(eMailId);
		logInDetails.setPWD_HASH(chngdPwd);
		setObjectInSession("logInSessionKey", logInDetails);
		return "success";
	}

	public void validate() {
		System.out.println("setting user action validation");
		boolean isDBCall = true;
		// valid email iD
		// should not exist
		// password and confirm password must have value
		// both should be same

		if (!Common.validateBlankStr((logInDetails.getEMailId()))) {
			addFieldError("logInDetails.eMailId", Common.getPropertyValue(
					"label-values", "mand.eMail.Id"));
			isDBCall = false;

		} else if (!Common.validateEmail(logInDetails.getEMailId())) {
			addFieldError("logInDetails.eMailId", Common.getPropertyValue(
					"label-values", "valid.emailId"));
			isDBCall = false;

		}
		if (pwdChngFlag == 'Y') {
			savePwdChngFlag = 'S';
			if (!((SignUpVO) getObjectFromSession("logInSessionKey"))
					.getPWD_HASH().equals(logInDetails.getOLD_PWD_HASH())) {
				addFieldError("logInDetails.OLD_PWD_HASH", Common
						.getPropertyValue("label-values", "old.password"));
				isDBCall = false;
				savePwdChngFlag = 'N';
			}
			if (!Common.validateBlankStr(logInDetails.getPWD_HASH())) {
				addFieldError("logInDetails.PWD_HASH", Common.getPropertyValue(
						"label-values", "mand.password"));
				isDBCall = false;
				savePwdChngFlag = 'N';
			}

			if (!Common.validateBlankStr(logInDetails.getConfrmPassword())) {
				addFieldError("logInDetails.confrmPassword ", Common
						.getPropertyValue("label-values", "mand.cnfPwd"));
				isDBCall = false;
				savePwdChngFlag = 'N';
			} else if (!(logInDetails.getConfrmPassword().equals(logInDetails
					.getPWD_HASH()))) {
				addFieldError("logInDetails.confrmPassword ", Common
						.getPropertyValue("label-values", "valid.pwd.cnfPwd"));
				isDBCall = false;
				savePwdChngFlag = 'N';
			}
		}
		if (isDBCall) {
			// check for duplicate user only if user Id is not same as old one
			System.out.println("old user ID" + getOldUserId()
					+ "logInDetails.getEMailId()" + logInDetails.getEMailId());
			if (!getOldUserId().equals(logInDetails.getEMailId())) {
				if (!userDAO.validateExistUserId(logInDetails.getEMailId())) {
					addFieldError("logInDetails.eMailId", Common
							.getPropertyValue("label-values",
									"valid.exist.emailId"));

				}
			}
		}
	}

	/**
	 * @return the logInDetails
	 */
	public SignUpVO getLogInDetails() {
		return logInDetails;
	}

	/**
	 * @param logInDetails
	 *            the logInDetails to set
	 */
	public void setLogInDetails(SignUpVO logInDetails) {
		this.logInDetails = logInDetails;
	}

	/**
	 * @return the userDAO
	 */
	public UserDAO getUserDAO() {
		return userDAO;
	}

	/**
	 * @param userDAO
	 *            the userDAO to set
	 */
	public void setUserDAO(UserDAO userDAO) {
		this.userDAO = userDAO;
	}

	/**
	 * @return the request
	 */
	public HttpServletRequest getRequest() {
		return this.request;
	}

	/**
	 * @param request
	 *            Sets the HTTP request object
	 */
	public void setServletRequest(final HttpServletRequest request) {
		this.request = request;
	}

	/**
	 * @return the response
	 */
	public HttpServletResponse getResponse() {
		return this.response;
	}

	/**
	 * @param response
	 *            Sets the HTTP response object
	 */
	public void setServletResponse(final HttpServletResponse response) {
		this.response = response;
	}

	/**
	 * @return the servletContext
	 */
	public ServletContext getServletContext() {
		return this.servletContext;
	}

	/**
	 * @param servletContext
	 *            Sets the context object
	 */
	public void setServletContext(ServletContext servletContext) {
		this.servletContext = servletContext;
	}

	public Object getObjectFromSession(String key) {
		session = request.getSession(true);
		if (null != session.getAttribute(key)) {
			return (Object) session.getAttribute(key);
		}
		return null;
	}

	public void setObjectInSession(String LOGIN_SESSION_KEY, Object obj) {
		session = request.getSession(true);
		// remove old details
		if (null != session.getAttribute(LOGIN_SESSION_KEY)) {
			session.removeAttribute(LOGIN_SESSION_KEY);
		}
		session.setAttribute(LOGIN_SESSION_KEY, obj);
	}

	/**
	 * @return the pwdChngFlag
	 */
	public char getPwdChngFlag() {
		return pwdChngFlag;
	}

	/**
	 * @param pwdChngFlag
	 *            the pwdChngFlag to set
	 */
	public void setPwdChngFlag(char pwdChngFlag) {
		this.pwdChngFlag = pwdChngFlag;
	}
}
