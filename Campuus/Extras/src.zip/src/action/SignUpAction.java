/**
 * 
 */
package action;

import java.sql.Timestamp;
import java.util.Date;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.InterceptorRef;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;

import com.opensymphony.xwork2.ActionSupport;

import utl_package.Common;
import vo.SignUpVO;
import dao.UserDAO;

/**
 * @author
 * 
 */
@ParentPackage(value = "certi-default")
@InterceptorRef("jsonValidationWorkflowStack")
public class SignUpAction extends ActionSupport {


	/**
	 * 
	 */
	private static final long serialVersionUID = 123423565L;


	
	private SignUpVO logInDetails = new SignUpVO();

	// private UserVO userDetails;

	private UserDAO userDAO = new UserDAO();

	public void validate() {
		System.out.println("sign up validation called");
		boolean isDBCall = true;
		if (!Common.validateBlankStr(logInDetails.getFirstName())) {
			addFieldError("logInDetails.firstName", Common.getPropertyValue(
					"label-values", "mand.firstName"));
			isDBCall = false;
		}

		if (!Common.validateBlankStr(logInDetails.getLastName())) {
			addFieldError("logInDetails.lastName", Common.getPropertyValue(
					"label-values", "mand.lastName"));
			isDBCall = false;
		}

		if (!Common.validateBlankStr((logInDetails.getEMailId()))) {
			addFieldError("logInDetails.eMailId", Common.getPropertyValue(
					"label-values", "mand.eMail.Id"));
			isDBCall = false;

		} else if (!Common.validateEmail(logInDetails.getEMailId())) {
			addFieldError("logInDetails.eMailId", Common.getPropertyValue(
					"label-values", "valid.emailId"));
			isDBCall = false;

		}

		if (!Common.validateBlankStr(logInDetails.getPWD_HASH())) {
			addFieldError("logInDetails.PWD_HASH", Common.getPropertyValue(
					"label-values", "mand.password"));
			isDBCall = false;
		}
		if (!Common.validateBlankStr(logInDetails.getConfrmPassword())) {
			addFieldError("logInDetails.confrmPassword ", Common
					.getPropertyValue("label-values", "mand.cnfPwd"));
			isDBCall = false;
		} else if (!(logInDetails.getConfrmPassword().equals(logInDetails
				.getPWD_HASH()))) {
			addFieldError("logInDetails.confrmPassword ", Common
					.getPropertyValue("label-values", "valid.pwd.cnfPwd"));
			isDBCall = false;
		}

		if (isDBCall){
			//check for duplicate user
			if(!userDAO.validateExistUserId( logInDetails.getEMailId())){
				addFieldError("logInDetails.eMailId", Common.getPropertyValue(
						"label-values", "valid.exist.emailId"));
					
			}
		}
	}

	@Action(value = "/signUp", results = { @Result(location = "eduQual.jsp", name = "success") })
	public String submitSignUp() {
		System.out.println("saving sign up" + logInDetails.getFirstName()
				+ logInDetails.getLastName() + logInDetails.getEMailId());
		String emailId = logInDetails.getEMailId();
		logInDetails.setUserName(emailId);
		logInDetails.setCREATED_BY(emailId);
		logInDetails.setLAST_UPD_BY(emailId);
		Timestamp currentTime = new Timestamp(new Date().getTime());
		logInDetails.setCR_DATE(currentTime);
		logInDetails.setLAST_UPD(currentTime);
		logInDetails.setFailedLogins(0);
		userDAO.addUsr(logInDetails);
		return "success";

	}

	/**
	 * @return the logInDetails
	 */
	public SignUpVO getLogInDetails() {
		return logInDetails;
	}

	/**
	 * @param logInDetails
	 *            the logInDetails to set
	 */
	public void setLogInDetails(SignUpVO logInDetails) {
		this.logInDetails = logInDetails;
	}

	/**
	 * @return the userDAO
	 */
	public UserDAO getUserDAO() {
		return userDAO;
	}

	/**
	 * @param userDAO
	 *            the userDAO to set
	 */
	public void setUserDAO(UserDAO userDAO) {
		this.userDAO = userDAO;
	}

}
