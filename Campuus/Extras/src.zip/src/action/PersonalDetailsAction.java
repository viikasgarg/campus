package action;

import java.io.File;
import java.io.FileInputStream;

import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.InterceptorRef;
import org.apache.struts2.convention.annotation.InterceptorRefs;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;
import org.apache.struts2.interceptor.validation.SkipValidation;

import com.opensymphony.xwork2.ActionSupport;

import dao.UserDAO;

import utl_package.Common;
import vo.PersonalDetailVO;

@ParentPackage(value = "certi-default")
@InterceptorRefs({@InterceptorRef("fileUploadStack"),@InterceptorRef("jsonValidationWorkflowStack")})
public class PersonalDetailsAction extends ActionSupport {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private PersonalDetailVO personalDetails = new PersonalDetailVO();
	private UserDAO userDAO = new UserDAO();
	private File fileUpload;
	private String fileUploadContentType;
	private String fileUploadFileName;

	/**
	 * @return the fileUploadContentType
	 */
	public String getFileUploadContentType() {
		return fileUploadContentType;
	}

	/**
	 * @param fileUploadContentType
	 *            the fileUploadContentType to set
	 */
	public void setFileUploadContentType(String fileUploadContentType) {
		this.fileUploadContentType = fileUploadContentType;
	}

	/**
	 * @return the fileUploadFileName
	 */
	public String getFileUploadFileName() {
		return fileUploadFileName;
	}

	/**
	 * @param fileUploadFileName
	 *            the fileUploadFileName to set
	 */
	public void setFileUploadFileName(String fileUploadFileName) {
		this.fileUploadFileName = fileUploadFileName;
	}

	/**
	 * @return the fileUpload
	 */
	public File getFileUpload() {
		return fileUpload;
	}

	/**
	 * @param fileUpload
	 *            the fileUpload to set
	 */
	public void setFileUpload(File fileUpload) {
		this.fileUpload = fileUpload;
	}

	public void validate() {
		// System.out.println(fileUpload);
		System.out.println("validate personal details1");
		boolean isDBCall = true;
		if (!Common.validateBlankStr(personalDetails.getFirstName())) {
			addFieldError("personalDetails.firstName", Common.getPropertyValue(
					"label-values", "mand.firstName"));
			isDBCall = false;
		}

		if (!Common.validateBlankStr(personalDetails.getLastName())) {
			addFieldError("personalDetails.lastName", Common.getPropertyValue(
					"label-values", "mand.lastName"));
			isDBCall = false;
		}

		if (!Common.validateBlankStr((personalDetails.getEMailId()))) {
			addFieldError("personalDetails.eMailId", Common.getPropertyValue(
					"label-values", "mand.eMail.Id"));
			isDBCall = false;

		} else if (!Common.validateEmail(personalDetails.getEMailId())) {
			addFieldError("personalDetails.eMailId", Common.getPropertyValue(
					"label-values", "valid.emailId"));
			isDBCall = false;

		}
		
		if (personalDetails.getSex().equals("-1")) {
			addFieldError("personalDetails.sex", Common.getPropertyValue(
					"label-values", "mand.sex"));
			isDBCall = false;

		}
		
		//check for mobile no, landline no, pincode numeric validation
		if(personalDetails.getMobileNo()!=null){
			if(!Common.validateNumber(personalDetails.getMobileNo())){
				addFieldError("personalDetails.mobileNo", Common.getPropertyValue(
						"label-values", "valid.mobileNo"));
				isDBCall = false;
			
			}
		}
		
		if(personalDetails.getLandlineNo()!=null){
			if(!Common.validateNumber(personalDetails.getLandlineNo())){
				addFieldError("personalDetails.landlineNo", Common.getPropertyValue(
						"label-values", "mand.lndlineNo"));
				isDBCall = false;
			}
		}
		/*if(!Common.validateNumber(personalDetails.getPincode)){
			addFieldError("personalDetails.pincode", Common.getPropertyValue(
					"label-values", "mand.pincode"));
			isDBCall = false;
		}*/
		
	/*	if (isDBCall) {
			// check for duplicate user
			if (userDAO.validateExistUserId(personalDetails.getEMailId())) {
				addFieldError("personalDetails.eMailId", Common.getPropertyValue(
						"label-values", "valid.exist.emailId"));

			}
		}
*/	}

	@Action(value = "/loadPersonal", results = { @Result(location = "personaldtls.jsp", name = "success") })
	@SkipValidation
	public String loadPersonal() {
		System.out.println("loadPersonal");

		return "success";

	}

	@Action(value = "/savePerDetails", results = {
			@Result(location = "eduQual.jsp", name = "success"),
			@Result(location = "personaldtls.jsp", name = "input") })
	
	public String saveEdDtls() {
		System.out.println("action popup callled");
		// logInDetails.setFirstName("");
		System.out.println("logInDetails.Image" + personalDetails.getImage());
		System.out.println("logInDetails.firstName"
				+ personalDetails.getAddId());
		personalDetails.setUSR_ID(5);
		personalDetails.setFax("3737373737");

		byte[] bFile = new byte[(int) fileUpload.length()];

		try {
			FileInputStream fileInputStream = new FileInputStream(fileUpload);
			// convert file into array of bytes
			fileInputStream.read(bFile);
			fileInputStream.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

		personalDetails.setImage(bFile);
		userDAO.add(personalDetails);
		return "success";
	}

	public PersonalDetailVO getPersonalDetails() {
		return personalDetails;
	}

	public void setPersonalDetails(PersonalDetailVO personalDetails) {
		this.personalDetails = personalDetails;
	}
}
