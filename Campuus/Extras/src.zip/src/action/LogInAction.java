package action;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.InterceptorRef;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;
import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.struts2.interceptor.ServletResponseAware;
import org.apache.struts2.interceptor.validation.SkipValidation;

import utl_package.Common;
import vo.SignUpVO;

import com.opensymphony.xwork2.ActionSupport;

import dao.UserDAO;

@ParentPackage(value = "certi-default")
@InterceptorRef("jsonValidationWorkflowStack")
public class LogInAction extends ActionSupport implements ServletRequestAware,
		ServletResponseAware {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private Logger logger = Logger.getLogger(LogInAction.class);

	private Class<LogInAction> thisClass = LogInAction.class;

	private SignUpVO logInDetails = new SignUpVO();

	// servlet request object
	protected HttpServletRequest request;

	// servlet response object
	protected HttpServletResponse response;

	// servlet session object
	protected HttpSession session = null;

	// servlet context object
	protected ServletContext servletContext = null;

	// private UserVO userDetails;

	private UserDAO userDAO = new UserDAO();

	private final String LOGIN_SESSION_KEY = "logInSessionKey";

	public void validate() {
		System.out.println("Inside Validate Method :: ");
		boolean isDBCall = true;
		if (!Common.validateBlankStr((logInDetails.getPWD_HASH()))) {
			addFieldError("logInDetails.PWD_HASH", Common.getPropertyValue(
					"label-values", "mand.password"));
			isDBCall = false;
		}

		if (!Common.validateBlankStr((logInDetails.getUserName()))) {
			addFieldError("logInDetails.userName", Common.getPropertyValue(
					"label-values", "mand.eMail.Id"));
			isDBCall = false;
		} else {
			if (!Common.validateEmail(logInDetails.getUserName())) {
				addFieldError("logInDetails.userName", Common.getPropertyValue(
						"label-values", "valid.emailId"));
				isDBCall = false;
			}

		}
		if (isDBCall) {
			// make db call
			SignUpVO signVo = new SignUpVO();
			signVo = userDAO.validateLogIn(logInDetails.getUserName(),
					logInDetails.getPWD_HASH());

			if (signVo == null) {
				// details not present
				addFieldError("logInDetails.userName", Common.getPropertyValue(
						"label-values", "valid.logIn"));
			} else {
				// check if password is matching
				if (logInDetails.getPWD_HASH().equals(signVo.getPWD_HASH())) {
					// if matched set user details in session
					session = request.getSession(true);
					//remove old details
					if (null != session.getAttribute(LOGIN_SESSION_KEY)) {
						session.removeAttribute(LOGIN_SESSION_KEY);
					}
					session.setAttribute(LOGIN_SESSION_KEY, signVo);
				} else {
					// password not present
					addFieldError("logInDetails.userName", Common
							.getPropertyValue("label-values", "valid.logIn"));
				}
			}
		}
	}

	@Action(value = "/popUpEduDtls", results = { @Result(location = "popUpEduDtls.jsp", name = "success") })
	@SkipValidation
	public String popUpEduDtls() {
		System.out.println("action pdsdopup callled");
		return "success";
	}

	@Action(value = "/openPopUp", results = { @Result(location = "popUpWorkExp.jsp", name = "success") })
	@SkipValidation
	public String openPopUp() {
		System.out.println("action popup callled");
		return "success";
	}

	@Action(value = "/updtEducDetls")
	public String updtEducDetls() {
		System.out.println("action callled");
		return "success";
	}

	@Action(value = "/welcome", results = {
			@Result(location = "navigation.jsp", name = "success"),
			@Result(location = "logIn.jsp", name = "input") })
	public String logInAction1() {
		try {
			//user details from session
			logInDetails = (SignUpVO) getObjectFromSession(LOGIN_SESSION_KEY);
			System.out.println("Loginn user details :: "+ logInDetails.getFirstName());
			// get object if exists then set in session
			System.out.println("welcome action");

		} catch (Exception e) {
			System.out
					.println("Error Occured while saving ::" + e.getMessage());
		}

		return "success";

	}

	@Action(value = "/loadSignUp", results = { @Result(location = "signUp.jsp", name = "success") })
	@SkipValidation
	public String loadSignUp() {
		System.out.println("loading sign up");
		return "success";

	}

	@Action(value = "/loadEdqual", results = { @Result(location = "eduQual.jsp", name = "success") })
	@SkipValidation
	public String loadEdqual() {
		System.out.println("loadEdqual ");

		return "success";

	}

	@Action(value = "/loadWorkex", results = { @Result(location = "workExp.jsp", name = "success") })
	@SkipValidation
	public String loadWorkex() {
		System.out.println("loadWorkex sign up");

		return "success";

	}

	public SignUpVO getLogInDetails() {
		return logInDetails;
	}

	public void setLogInDetails(SignUpVO logInDetails) {
		this.logInDetails = logInDetails;
	}

	/**
	 * @return the request
	 */
	public HttpServletRequest getRequest() {
		return this.request;
	}

	/**
	 * @param request
	 *            Sets the HTTP request object
	 */
	public void setServletRequest(final HttpServletRequest request) {
		this.request = request;
	}

	/**
	 * @return the response
	 */
	public HttpServletResponse getResponse() {
		return this.response;
	}

	/**
	 * @param response
	 *            Sets the HTTP response object
	 */
	public void setServletResponse(final HttpServletResponse response) {
		this.response = response;
	}

	/**
	 * @return the servletContext
	 */
	public ServletContext getServletContext() {
		return this.servletContext;
	}

	/**
	 * @param servletContext
	 *            Sets the context object
	 */
	public void setServletContext(ServletContext servletContext) {
		this.servletContext = servletContext;
	}

	public Object getObjectFromSession(String key)
	{
		session = request.getSession(true);
		if (null != session.getAttribute(key))
		{
			return (Object) session.getAttribute(key);
		}
		return null;
	}
	

	@Action(value = "/createGroup", results = { @Result(location = "createGroup.jsp", name = "success") })
	@SkipValidation
	public String createGroup() {
		return "success";

	}
	
	@Action(value = "/homeExpense", results = { @Result(location = "sharingExpenseHome.jsp", name = "success") })
	@SkipValidation
	public String homeExpense() {		
		return "success";
	}
	
	
	
	@Action(value = "/createMember", results = { @Result(location = "createMember.jsp", name = "success") })
	@SkipValidation
	public String createMember() {		
		return "success";
	}
	
	@Action(value = "/createExpense", results = { @Result(location = "createExpense.jsp", name = "success") })
	@SkipValidation
	public String createExpense() {		
		return "success";
	}
	
	@Action(value = "/expenseSheet", results = { @Result(location = "expenseSheet.jsp", name = "success") })
	@SkipValidation
	public String expenseSheet() {		
		return "success";
	}
	
	@Action(value = "/helpExpense", results = { @Result(location = "helpExpense.jsp", name = "success") })
	@SkipValidation
	public String helpExpense() {		
		return "success";
	}
	

}