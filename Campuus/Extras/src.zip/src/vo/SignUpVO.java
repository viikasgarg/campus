package vo;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "usr")
public class SignUpVO {

	@Id
	@GeneratedValue
	private int USR_ID;
	@Column(name = "USERNAME")
	private String userName;
	@Column(name = "PWD_HASH")
	private String PWD_HASH;
	@Column(name = "FNAME")
	private String firstName;
	@Column(name = "LNAME")
	private String lastName;
	@Column(name = "EMAIL")
	private String eMailId;
	@Column(name = "CR_DATE")
	private Timestamp CR_DATE;
	@Column(name = "CREATED_BY")
	private String CREATED_BY;
	@Column(name = "LAST_UPD")
	private Timestamp LAST_UPD;
	@Column(name = "LAST_UPD_BY")
	private String LAST_UPD_BY;
	@Column(name = "FAILED_LOGINS")
	private int failedLogins;
	
	@javax.persistence.Transient
	private String confrmPassword;
	

	@javax.persistence.Transient
	private String OLD_PWD_HASH;
	
	/**
	 * @return the oLD_PWD_HASH
	 */
	public String getOLD_PWD_HASH() {
		return OLD_PWD_HASH;
	}

	/**
	 * @param old_pwd_hash the oLD_PWD_HASH to set
	 */
	public void setOLD_PWD_HASH(String old_pwd_hash) {
		OLD_PWD_HASH = old_pwd_hash;
	}

	/**
	 * @return the confrmPassword
	 */
	public String getConfrmPassword() {
		return confrmPassword;
	}

	/**
	 * @param confrmPassword the confrmPassword to set
	 */
	public void setConfrmPassword(String confrmPassword) {
		this.confrmPassword = confrmPassword;
	}

	public int getFailedLogins() {
		return failedLogins;
	}

	public void setFailedLogins(int failedLogins) {
		this.failedLogins = failedLogins;
	}

	public int getUSR_ID() {
		return USR_ID;
	}

	public void setUSR_ID(int uSR_ID) {
		System.out.println("===========uSR_ID============" + uSR_ID);
		this.USR_ID = uSR_ID;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		System.out.println("===========userName============" + userName);
		this.userName = userName;
	}

	public String getPWD_HASH() {
		return PWD_HASH;
	}

	public void setPWD_HASH(String pWD_HASH) {
		System.out.println("===========pWD_HASH============" + pWD_HASH);
		this.PWD_HASH = pWD_HASH;
	}

	public String getEMailId() {
		return eMailId;
	}

	public void setEMailId(String eMailId) {
		System.out.println("===========eMailId============" + eMailId);
		this.eMailId = eMailId;
	}

	public Timestamp getCR_DATE() {
		return CR_DATE;
	}

	public void setCR_DATE(Timestamp cR_DATE) {
		this.CR_DATE = cR_DATE;
	}

	public String getCREATED_BY() {
		return CREATED_BY;
	}

	public void setCREATED_BY(String cREATED_BY) {
		this.CREATED_BY = cREATED_BY;
	}

	public Timestamp getLAST_UPD() {
		return LAST_UPD;
	}

	public void setLAST_UPD(Timestamp lAST_UPD) {
		this.LAST_UPD = lAST_UPD;
	}

	public String getLAST_UPD_BY() {
		return LAST_UPD_BY;
	}

	public void setLAST_UPD_BY(String lAST_UPD_BY) {
		this.LAST_UPD_BY = lAST_UPD_BY;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		System.out.println("===========lastName============" + lastName);
		this.lastName = lastName;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		System.out.println("===========firstName============" + firstName);
		this.firstName = firstName;
	}
}