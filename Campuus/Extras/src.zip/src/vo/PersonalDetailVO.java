package vo;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import java.util.Date;

@Entity
@Table(name = "personal_details")
public class PersonalDetailVO {

	@Id
	private int USR_ID;
	@Column(name = "FNAME")
	private String firstName;
	@Column(name = "LNAME")
	private String lastName;
	@Column(name = "EMAIL")
	private String eMailId;
	@Column(name = "SEX")
	private String sex;
	@Column(name = "Birth_Date")
	private Date dob;
	@Column(name = "HOME_PHONE")
	private String landlineNo;
	@Column(name = "MOBILE_PHONE")
	private String mobileNo;
	@Column(name = "FAX")
	private String fax;
	@GeneratedValue
	@Column(name = "ADDR_ID")
	private String addId;
	@Column(name = "PROFILE_IMAGE")
	@Lob
	private byte[] image;

/*	@OneToOne(mappedBy = "personal_details", cascade = CascadeType.ALL)
	private addr addrVo;

	*//**
	 * @return the addrVo
	 *//*
	public addr getAddrVo() {
		return addrVo;
	}

	*//**
	 * @param addrVo
	 *            the addrVo to set
	 *//*
	public void setAddrVo(addr addrVo) {
		this.addrVo = addrVo;
	}*/

	/**
	 * @param dob
	 *            the dob to set
	 */
	public void setDob(Date dob) {
		this.dob = dob;
	}

	public int getUSR_ID() {
		return USR_ID;
	}

	public void setUSR_ID(int uSR_ID) {
		USR_ID = uSR_ID;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEMailId() {
		return eMailId;
	}

	public void setEMailId(String eMailId) {
		this.eMailId = eMailId;
	}

	public String getSex() {
		return sex;
	}

	public void setSex(String sex) {
		this.sex = sex;
	}

	public Date getDob() {
		return dob;
	}

	@SuppressWarnings("deprecation")
	public void setDob(String dob) {
		System.out.println("=================dob==================" + dob);
		this.dob = new Date(dob);
	}

	public String getLandlineNo() {
		return landlineNo;
	}

	public void setLandlineNo(String landlineNo) {
		this.landlineNo = landlineNo;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getFax() {
		return fax;
	}

	public void setFax(String fax) {
		this.fax = fax;
	}

	public String getAddId() {
		return addId;
	}

	public void setAddId(String addId) {
		this.addId = addId;
	}

	public byte[] getImage() {
		return image;
	}

	public void setImage(byte[] bFile) {
		this.image = bFile;
	}

}