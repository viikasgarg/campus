package vo;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "addr")
public class addr {
	@GeneratedValue
	@Id
	@Column(name = "ADDR_ID")
	private String addId;
	@Column(name = "ADDR1")
	private String ADDR1;
	@Column(name = "ADDR2")
	private String ADDR2;
	@Column(name = "ADDR3")
	private String ADDR3;
	@Column(name = "CITY")
	private String CITY;
	@Column(name = "STATE")
	private String STATE;
	@Column(name = "COUNTRY")
	private String COUNTRY;
	@Column(name = "ZIPCODE")
	private int ZIPCODE;
	@Column(name = "CR_DATE")
	private Date CR_DATE;
	@Column(name = "CREATED_BY")
	private String CREATED_BY;
	@Column(name = "LAST_UPD")
	private Date LAST_UPD;
	@Column(name = "LAST_UPD_BY")
	private String LAST_UPD_BY;
/*
	@OneToOne
	private PersonalDetailVO personalDtlsVo;

*/	/**
	 * @return the addId
	 */
	public String getAddId() {
		return addId;
	}

	/**
	 * @param addId
	 *            the addId to set
	 */
	public void setAddId(String addId) {
		this.addId = addId;
	}

/*	*//**
	 * @return the personalDtlsVo
	 *//*
	public PersonalDetailVO getPersonalDtlsVo() {
		return personalDtlsVo;
	}

	*//**
	 * @param personalDtlsVo
	 *            the personalDtlsVo to set
	 *//*
	public void setPersonalDtlsVo(PersonalDetailVO personalDtlsVo) {
		this.personalDtlsVo = personalDtlsVo;
	}
*/
	/**
	 * @return the aDDR1
	 */
	public String getADDR1() {
		return ADDR1;
	}

	/**
	 * @param addr1
	 *            the aDDR1 to set
	 */
	public void setADDR1(String addr1) {
		ADDR1 = addr1;
	}

	/**
	 * @return the aDDR2
	 */
	public String getADDR2() {
		return ADDR2;
	}

	/**
	 * @param addr2
	 *            the aDDR2 to set
	 */
	public void setADDR2(String addr2) {
		ADDR2 = addr2;
	}

	/**
	 * @return the aDDR3
	 */
	public String getADDR3() {
		return ADDR3;
	}

	/**
	 * @param addr3
	 *            the aDDR3 to set
	 */
	public void setADDR3(String addr3) {
		ADDR3 = addr3;
	}

	/**
	 * @return the cITY
	 */
	public String getCITY() {
		return CITY;
	}

	/**
	 * @param city
	 *            the cITY to set
	 */
	public void setCITY(String city) {
		CITY = city;
	}

	/**
	 * @return the sTATE
	 */
	public String getSTATE() {
		return STATE;
	}

	/**
	 * @param state
	 *            the sTATE to set
	 */
	public void setSTATE(String state) {
		STATE = state;
	}

	/**
	 * @return the cOUNTRY
	 */
	public String getCOUNTRY() {
		return COUNTRY;
	}

	/**
	 * @param country
	 *            the cOUNTRY to set
	 */
	public void setCOUNTRY(String country) {
		COUNTRY = country;
	}

	/**
	 * @return the zIPCODE
	 */
	public int getZIPCODE() {
		return ZIPCODE;
	}

	/**
	 * @param zipcode
	 *            the zIPCODE to set
	 */
	public void setZIPCODE(int zipcode) {
		ZIPCODE = zipcode;
	}

	/**
	 * @return the cR_DATE
	 */
	public Date getCR_DATE() {
		return CR_DATE;
	}

	/**
	 * @param cr_date
	 *            the cR_DATE to set
	 */
	public void setCR_DATE(Date cr_date) {
		CR_DATE = cr_date;
	}

	/**
	 * @return the cREATED_BY
	 */
	public String getCREATED_BY() {
		return CREATED_BY;
	}

	/**
	 * @param created_by
	 *            the cREATED_BY to set
	 */
	public void setCREATED_BY(String created_by) {
		CREATED_BY = created_by;
	}

	/**
	 * @return the lAST_UPD
	 */
	public Date getLAST_UPD() {
		return LAST_UPD;
	}

	/**
	 * @param last_upd
	 *            the lAST_UPD to set
	 */
	public void setLAST_UPD(Date last_upd) {
		LAST_UPD = last_upd;
	}

	/**
	 * @return the lAST_UPD_BY
	 */
	public String getLAST_UPD_BY() {
		return LAST_UPD_BY;
	}

	/**
	 * @param last_upd_by
	 *            the lAST_UPD_BY to set
	 */
	public void setLAST_UPD_BY(String last_upd_by) {
		LAST_UPD_BY = last_upd_by;
	}

}
