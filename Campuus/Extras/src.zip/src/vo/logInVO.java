package vo;

public class logInVO {
	private String userName;
	private String password;
	private String firstName;
	private String lastName;
	private String eMailId;
	private String confrmPassword;
	private String dob;
	private String sex;
	private int mobileNo;
	private int landlineNo;
	private String adressLine1;
	private String adressLine2;
	private String adressLine3;
	private String city;
	private String state;
	private String country;
	private int pincode;
	private String emplrName;
	private String startMonth;
	private String startYear;
	private String endMonth;
	private String endYear;
	private String designation;
	private String jobProfile;
	private String specialization;
	private String certName;
	private String univInst;
	private String edYear;
	private String courseName;
	private int countOfRecords;
	private String emplDuration;
	private int actionId;

	/**
	 * @return the actionId
	 */
	public int getActionId() {
		return actionId;
	}

	/**
	 * @param actionId the actionId to set
	 */
	public void setActionId(int actionId) {
		this.actionId = actionId;
	}

	/**
	 * @return the emplDuration
	 */
	public String getEmplDuration() {
		return emplDuration;
	}

	/**
	 * @param emplDuration the emplDuration to set
	 */
	public void setEmplDuration(String emplDuration) {
		this.emplDuration = emplDuration;
	}

	/**
	 * @return the jobProfile
	 */
	public String getJobProfile() {
		return jobProfile;
	}

	/**
	 * @param jobProfile the jobProfile to set
	 */
	public void setJobProfile(String jobProfile) {
		this.jobProfile = jobProfile;
	}

	/**
	 * @return the specialization
	 */
	public String getSpecialization() {
		return specialization;
	}

	/**
	 * @param specialization the specialization to set
	 */
	public void setSpecialization(String specialization) {
		this.specialization = specialization;
	}

	/**
	 * @return the courseName
	 */
	public String getCourseName() {
		return courseName;
	}

	/**
	 * @param courseName the courseName to set
	 */
	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}

	/**
	 * @return the countOfRecords
	 */
	public int getCountOfRecords() {
		return countOfRecords;
	}

	/**
	 * @param countOfRecords the countOfRecords to set
	 */
	public void setCountOfRecords(int countOfRecords) {
		this.countOfRecords = countOfRecords;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEMailId() {
		return eMailId;
	}

	public void setEMailId(String mailId) {
		eMailId = mailId;
	}

	public String getConfrmPassword() {
		return confrmPassword;
	}

	public void setConfrmPassword(String confrmPassword) {
		this.confrmPassword = confrmPassword;
	}

	/**
	 * @return the dob
	 */
	public String getDob() {
		return dob;
	}

	/**
	 * @param dob the dob to set
	 */
	public void setDob(String dob) {
		this.dob = dob;
	}

	/**
	 * @return the sex
	 */
	public String getSex() {
		return sex;
	}

	/**
	 * @param sex the sex to set
	 */
	public void setSex(String sex) {
		this.sex = sex;
	}

	/**
	 * @return the mobileNo
	 */
	public int getMobileNo() {
		return mobileNo;
	}

	/**
	 * @param mobileNo the mobileNo to set
	 */
	public void setMobileNo(int mobileNo) {
		this.mobileNo = mobileNo;
	}

	/**
	 * @return the landlineNo
	 */
	public int getLandlineNo() {
		return landlineNo;
	}

	/**
	 * @param landlineNo the landlineNo to set
	 */
	public void setLandlineNo(int landlineNo) {
		this.landlineNo = landlineNo;
	}

	/**
	 * @return the adressLine1
	 */
	public String getAdressLine1() {
		return adressLine1;
	}

	/**
	 * @param adressLine1 the adressLine1 to set
	 */
	public void setAdressLine1(String adressLine1) {
		this.adressLine1 = adressLine1;
	}

	/**
	 * @return the adressLine2
	 */
	public String getAdressLine2() {
		return adressLine2;
	}

	/**
	 * @param adressLine2 the adressLine2 to set
	 */
	public void setAdressLine2(String adressLine2) {
		this.adressLine2 = adressLine2;
	}

	/**
	 * @return the adressLine3
	 */
	public String getAdressLine3() {
		return adressLine3;
	}

	/**
	 * @param adressLine3 the adressLine3 to set
	 */
	public void setAdressLine3(String adressLine3) {
		this.adressLine3 = adressLine3;
	}

	/**
	 * @return the city
	 */
	public String getCity() {
		return city;
	}

	/**
	 * @param city the city to set
	 */
	public void setCity(String city) {
		this.city = city;
	}

	/**
	 * @return the state
	 */
	public String getState() {
		return state;
	}

	/**
	 * @param state the state to set
	 */
	public void setState(String state) {
		this.state = state;
	}

	/**
	 * @return the country
	 */
	public String getCountry() {
		return country;
	}

	/**
	 * @param country the country to set
	 */
	public void setCountry(String country) {
		this.country = country;
	}

	/**
	 * @return the pincode
	 */
	public int getPincode() {
		return pincode;
	}

	/**
	 * @param pincode the pincode to set
	 */
	public void setPincode(int pincode) {
		this.pincode = pincode;
	}

	/**
	 * @return the emplrName
	 */
	public String getEmplrName() {
		return emplrName;
	}

	/**
	 * @param emplrName the emplrName to set
	 */
	public void setEmplrName(String emplrName) {
		this.emplrName = emplrName;
	}

	/**
	 * @return the startMonth
	 */
	public String getStartMonth() {
		return startMonth;
	}

	/**
	 * @param startMonth the startMonth to set
	 */
	public void setStartMonth(String startMonth) {
		this.startMonth = startMonth;
	}

	/**
	 * @return the startYear
	 */
	public String getStartYear() {
		return startYear;
	}

	/**
	 * @param startYear the startYear to set
	 */
	public void setStartYear(String startYear) {
		this.startYear = startYear;
	}

	/**
	 * @return the endMonth
	 */
	public String getEndMonth() {
		return endMonth;
	}

	/**
	 * @param endMonth the endMonth to set
	 */
	public void setEndMonth(String endMonth) {
		this.endMonth = endMonth;
	}

	/**
	 * @return the endYear
	 */
	public String getEndYear() {
		return endYear;
	}

	/**
	 * @param endYear the endYear to set
	 */
	public void setEndYear(String endYear) {
		this.endYear = endYear;
	}

	/**
	 * @return the designation
	 */
	public String getDesignation() {
		return designation;
	}

	/**
	 * @param designation the designation to set
	 */
	public void setDesignation(String designation) {
		this.designation = designation;
	}

	/**
	 * @return the certName
	 */
	public String getCertName() {
		return certName;
	}

	/**
	 * @param certName the certName to set
	 */
	public void setCertName(String certName) {
		this.certName = certName;
	}

	/**
	 * @return the univInst
	 */
	public String getUnivInst() {
		return univInst;
	}

	/**
	 * @param univInst the univInst to set
	 */
	public void setUnivInst(String univInst) {
		this.univInst = univInst;
	}

	/**
	 * @return the edYear
	 */
	public String getEdYear() {
		return edYear;
	}

	/**
	 * @param edYear the edYear to set
	 */
	public void setEdYear(String edYear) {
		this.edYear = edYear;
	}

}
