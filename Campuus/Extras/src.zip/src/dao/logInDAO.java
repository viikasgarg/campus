/**
 * 
 */
package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

import javax.sql.DataSource;


import org.springframework.jdbc.core.simple.SimpleJdbcTemplate;

import vo.logInVO;

/**
 * @author
 * 
 */
public class logInDAO {
	private SimpleJdbcTemplate simpleJdbcTemplate;
	private DataSource dataSource;

	// Set data Source name
	public void setDataSource(DataSource dataSource) {
		this.simpleJdbcTemplate = new SimpleJdbcTemplate(dataSource);
	}

	public logInVO saveUserDetails(logInVO logInDetails) {
		System.out.println("saveUserDetails:: dao called ");
		int i = this.simpleJdbcTemplate.queryForInt("select 1 from dual");
		System.out.println("i :: " + i);
		return null;
	}
/*
	public String dataCall() {
		// insert into db
		Connection conn = null;
		String url = "jdbc:mysql://localhost:3306/";
		String dbName = "certi_cloud"; // it is same as schema name in
		// Database
		String driver = "com.mysql.jdbc.Driver";
		String userName = "root";
		String password1 = "nikhil";
		// int counter;
		try {
			// Class.forName(driver).newInstance();
			Class.forName(driver);
			System.out.println("After Class");
			conn = DriverManager.getConnection(url + dbName, userName,
					password1);
			System.out.println("Connected to database");
			Statement st = conn.createStatement();
			//

			System.out.println("asdfsd");
			Object[] args;
			// args = new Object[] { 3, "user2" };
			System.out.println("Before insert");
			String queryStr = "insert into certi_cloud.cc_user_role_mast values ("
					+ 3 + ",'user2')";
			// String queryStr = "insert into cc_user_role_mast values (?,?)";
			System.out.println("�fter insert" + queryStr);

			// int value = st.executeUpdate(queryStr);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return "a";
	}
*/
}
