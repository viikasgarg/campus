package dao;

import java.sql.Timestamp;
import java.text.Normalizer.Form;
import java.util.Date;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;

import vo.PersonalDetailVO;
import vo.SignUpVO;

import com.googlecode.s2hibernate.struts2.plugin.annotations.SessionTarget;
import com.googlecode.s2hibernate.struts2.plugin.annotations.TransactionTarget;

public class UserDAO {

	private static SessionFactory sessionFactory;

	private static SessionFactory buildSessionFactory() {
		try {
			// Create the SessionFactory from hibernate.cfg.xml
			return new AnnotationConfiguration().addAnnotatedClass(
					SignUpVO.class).configure().buildSessionFactory();
		} catch (Throwable ex) {
			System.err.println("Initial SessionFactory creation failed." + ex);
			throw new ExceptionInInitializerError(ex);
		}
	}

	public static SessionFactory getSessionFactory() {
		sessionFactory = buildSessionFactory();
		return sessionFactory;
	}

	@SessionTarget
	Session session;

	@TransactionTarget
	Transaction transaction;

	// @SuppressWarnings("unchecked")
	// public List<UserVO> getStudents()
	// {
	// List<UserVO> students = new ArrayList<UserVO>();
	// try
	// {
	// students = session.createQuery("from Student").list();
	// }
	// catch(Exception e)
	// {
	// e.printStackTrace();
	// }
	// return students;
	// }
	public SignUpVO validateLogIn(String userId, String pwd) {
		SignUpVO signVo = new SignUpVO();

		session = getSessionFactory().getCurrentSession();
		session.beginTransaction();

		signVo = (SignUpVO) session.createQuery(
				"from SignUpVO where userName = '" + userId + "'")
				.uniqueResult();
		System.out.println("asdfsdf" + signVo.getUSR_ID());
		session.getTransaction().commit();

		return signVo;
	}

	public void addUsr(SignUpVO student) {
		try {
			session = getSessionFactory().getCurrentSession();
			session.beginTransaction();
			session.save(student);
			session.getTransaction().commit();
		} catch (HibernateException e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
	}

	public void add(PersonalDetailVO student) {
		System.out.println("============" + student.getFirstName());
		System.out.println("============" + student.getLastName());
		try {
			session = getSessionFactory().getCurrentSession();
			session.beginTransaction();
			session.save(student);
			session.getTransaction().commit();
		} catch (HibernateException e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
	}

	@SuppressWarnings("unchecked")
	public boolean validateExistUserId(String mailId) {
		// made DB call to check for existing User
		SignUpVO student = null;
		try {
			session = getSessionFactory().getCurrentSession();
			session.beginTransaction();
			student = (SignUpVO) session.createQuery(
					"from SignUpVO where userName = '" + mailId + "'")
					.uniqueResult();
			session.getTransaction().commit();

		} catch (Exception e) {
			e.printStackTrace();
		}
		if (student != null)
			return false;
		else
			return true;
	}

	public void saveModDetails(SignUpVO logInDetails, char pwdChngFlag) {
		session = getSessionFactory().getCurrentSession();
		session.beginTransaction();
		System.out.println(logInDetails.getUSR_ID());
		SignUpVO sg = (SignUpVO) session.load(SignUpVO.class, logInDetails
				.getUSR_ID());
		sg.setEMailId(logInDetails.getEMailId());
		
		sg.setUserName(logInDetails.getEMailId());
		Timestamp t = new Timestamp(new Date().getTime());
		sg.setLAST_UPD(t);

		if (pwdChngFlag == 'S') {
			sg.setPWD_HASH(logInDetails.getPWD_HASH());
		}
		session.update(sg);
		// "SignUpVO set userName=''"+logInDetails.getEMailId()+"' where
		// userName='"+oldUserId+"'");

		session.getTransaction().commit();

	}

}