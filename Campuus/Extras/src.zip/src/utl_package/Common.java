package utl_package;

import java.util.ResourceBundle;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Common {
	private static Pattern pattern;
	private static Matcher matcher;
	private static final String EMAIL_PATTERN = "^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"
			+ "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";

	public static String getPropertyValue(String propFileName, String key) {
		ResourceBundle bundle = ResourceBundle.getBundle(propFileName);
		String strVal = bundle.getString(key);
		if (strVal == null) {
			strVal = "";
		}
		bundle = null;
		return strVal;
	}

	// check for blank values
	public static boolean validateBlankStr(String inpt) {

		if (inpt == null || inpt.trim().equalsIgnoreCase("")) {
			return false;
		} else {
			return true;
		}

	}

	/**
	 * Validate hex with regular expression
	 * 
	 * @param hex
	 *            hex for validation
	 * @return true valid hex, false invalid hex
	 */
	public static boolean validateEmail(String hex) {

		pattern = Pattern.compile(EMAIL_PATTERN);
		matcher = pattern.matcher(hex);

		return matcher.matches();

	}
	
	/**
	 * @param number
	 * @return true if number is number else string
	 */
	public static boolean validateNumber(String number) {

		pattern = Pattern.compile("[0-9]+");
		matcher = pattern.matcher(number);

		return matcher.matches();

	}

}
