import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Iterator;

import javax.imageio.IIOImage;
import javax.imageio.ImageIO;
import javax.imageio.ImageWriteParam;
import javax.imageio.ImageWriter;
import javax.imageio.stream.FileImageOutputStream;
import javax.imageio.stream.ImageOutputStream;

public class testClass {
	public static void main(String[] args) {
		try {
			/*
			 * File file = new
			 * File("C:/Users/nikhil_singla/Desktop/passport1.png");
			 * System.out.println("size of file in KB :: " + (int) file.length() /
			 * (1024));
			 * 
			 * BufferedImage buffImage = ImageIO.read(file);
			 */
			// compressJpegImage(buffImage, 0.3f);
			// to convert the format
			System.out.println("Enter image name\n");
			BufferedReader bf = new BufferedReader(new InputStreamReader(
					System.in));
			String imageName = bf.readLine();
			File input = new File(imageName);
			BufferedImage image = ImageIO.read(input);
			System.out.println("Enter the output image name(.jpg):\n");
			String imageName1 = bf.readLine();
			File output = new File(imageName1);
			ImageIO.write(image, "jpg", output);
			System.out.println("Your image has been converted successfully");

		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}

	public static void compressJpegImage(BufferedImage image, float quality)
			throws IOException {
		// Get a ImageWriter for jpeg format.
		Iterator<ImageWriter> writers = ImageIO.getImageWritersBySuffix("jpeg");
		if (!writers.hasNext())
			throw new IllegalStateException("No writers found");
		ImageWriter writer = (ImageWriter) writers.next();
		// Create the ImageWriteParam to compress the image.
		ImageWriteParam param = writer.getDefaultWriteParam();
		param.setCompressionMode(ImageWriteParam.MODE_EXPLICIT);
		param.setCompressionQuality(quality);
		// The output will be a ByteArrayOutputStream (in memory)
		ByteArrayOutputStream bos = new ByteArrayOutputStream(32768);
		ImageOutputStream ios = ImageIO.createImageOutputStream(bos);
		writer.setOutput(ios);
		writer.write(null, new IIOImage(image, null, null), param);
		ios.flush(); // otherwise the buffer size will be zero!
		int size = bos.toByteArray().length;
		System.out.println("Output File Size :: " + (int) size / 1024);
		// code below to save the compressed files.
		File file = new File("C:/Users/nikhil_singla/Desktop/compressed."
				+ quality + ".jpeg");
		FileImageOutputStream output = new FileImageOutputStream(file);
		writer.setOutput(output);
		writer.write(null, new IIOImage(image, null, null), param);
	}

}
