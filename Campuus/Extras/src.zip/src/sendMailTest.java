
public class sendMailTest {/*

	public static void main(String[] args) {
		// Extract the data
		String smtpServer = "smtp.gmail.com";
		String[] to = { "nikhilsingla.88@gmail.com" };

		String from = "nikhilsingla.88@gmail.com";
		String subject = "TestMail";
		String body = "Mail Body";

		String d_port = "465";

		try {
			Properties props = System.getProperties();
			// Attaching to default Session, or we could start a new one --
			props.put("mail.smtp.host", smtpServer);
			props.put("mail.smtp.port", d_port);
			Session session = Session.getDefaultInstance(props, null);

			// Create a new message --
			Message msg = new MimeMessage(session);

			// Set the FROM and TO fields --
			System.out.println("From..." + from);

			msg.setFrom(new InternetAddress(from));

			InternetAddress[] iadd = new InternetAddress[to.length];
			for (int i = 0; i < iadd.length; i++) {
				iadd[i] = new InternetAddress(to[i]);
			}
			msg.setRecipients(Message.RecipientType.TO, iadd);

			// Set the subject and body text --
			msg.setSubject(subject);

			msg.setText(body);

			msg.setSentDate(new Date(0));
			Transport transport = session.getTransport("smtp");
			transport.connect(smtpServer, "nikhilsingla.88@gmail.com", "");
			// Send the message --
			Transport.send(msg);
			transport.close();
		} catch (Exception ex) {
			System.out.println("Mail Sending failed Exception IS-->");
			ex.printStackTrace();

		}
	}

*/}
