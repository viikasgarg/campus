/**
 * 
 */
package bo;

import vo.logInVO;
import dao.logInDAO;

/**
 * @author 
 *
 */
public class logInBO {
	private logInDAO logInDao;
	/**
	 * @return the logInDao
	 */
	public logInDAO getLogInDao() {
		return logInDao;
	}
	/**
	 * @param logInDao the logInDao to set
	 */
	public void setLogInDao(logInDAO logInDao) {
		this.logInDao = logInDao;
	}
	public logInVO saveUserDetails(logInVO logInDetails){
		return logInDao.saveUserDetails(logInDetails);
	}
}
