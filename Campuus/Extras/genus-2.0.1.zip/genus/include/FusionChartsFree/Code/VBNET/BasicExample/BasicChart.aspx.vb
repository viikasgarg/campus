﻿
Partial Class BasicExample_BasicChart
    Inherits System.Web.UI.Page

End Class
