﻿
Partial Class BasicExample_MultiChart
    Inherits System.Web.UI.Page

End Class
