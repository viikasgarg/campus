FusionCharts Free v2.1 by Infosoft Global (P) Ltd.

URL: www.fusioncharts.com/free
URL: www.infosoftglobal.com
Email: support@fusioncharts.com

Please run Index.html to launch the documentation. Then, browse to "Installation" page to get instructions on how to install FusionCharts Free and use it in your projects.

License Agreement can be found at http://www.fusioncharts.com/free/TermsOfUse.asp