<?php
/** ensure this file is being included by a parent file */
defined( '_VALID_MVH' ) or die( 'Direct Access to this location is not allowed.' );

$pref_show_home_popular=false;
$pref_show_home_footer=true;

$invoice_company_name = "";
$invoice_address = "";

?>